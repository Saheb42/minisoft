<?php

namespace App\Http\Controllers\Admin;

use App\Helpers\Helper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Maincontroller extends Controller
{
    public function index()
    {
        # code...
        return view('Admin.Pages.dashboard');
    }
    public function service_view()
    {
        # code...
        // Helper::get_count();
        $data = DB::table('services')->get();
        // dd($data);
        return view('Admin.Pages.Services.view', compact('data'));
    }
    public function service_chk_single_data(Request $request)
    {
        $req = $request->query();

        $data = Helper::get_count(
            $req['t_n'],
            $req['f_n'],
            $req['f_v']
        );
        return response()->json($data);
        # code...
    }


    public function staffs_view()
    {
        return view('Admin.Pages.Staffs.view');
    }
}
