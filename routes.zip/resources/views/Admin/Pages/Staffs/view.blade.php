@extends('Admin.Layout.main')

@section('title')
<title>Staffs View</title>
@endsection
@section('main_section')

<div class="card m-1">
    <div class="card-body row">
        <div class="col-md-4">
            <form action="#" method="post" class="row">
                @csrf
                <div class="col-md-12 mb-4">
                    <label class="from-label mb-2">Aadhaar Card</label>
                    <input type="text" id="aadhaar_card" name="aadhaar_card" placeholder="Enter Service Name" aria-describedby="emailHelp" class="form-control">
                    <div id="aadhaar_card_msg">
                    </div>
                </div>
                <div style="display:none;" id="other_section">
                    <div class="col-md-6 mb-4">
                        <label class="from-label mb-2">Service Price</label>
                        <input type="text" id="ser_price" name="ser_price" placeholder="Enter Service Price" aria-describedby="emailHelp" class="form-control">
                        <span class="text-danger" id="ser_price_msg"></span>
                    </div>
                    <div class="col-md-6 mb-4">
                        <label class="from-label mb-2">Expenses</label>
                        <input type="text" id="ser_expenses" name="ser_expenses" placeholder="Enter Expenses" aria-describedby="emailHelp" class="form-control">
                        <span class="text-danger" id="ser_expenses_msg"></span>
                    </div>
                    <div class="col-md-12 mb-4" id="com_div_1">
                        <label class="from-label mb-2">Commission 1</label>
                        <input type="text" id="ser_com1" name="ser_com1" placeholder="Enter Commission 1" aria-describedby="emailHelp" class="form-control">
                        <span class="text-danger" id="ser_com1_msg"></span>
                    </div>
                    <div class="col-md-6 mb-4" id="com_div_2">
                        <label class="from-label mb-2">Commission 2</label>
                        <input type="text" id="ser_com2" name="ser_com2" placeholder="Enter Commission 2" aria-describedby="emailHelp" class="form-control">
                        <span class="text-danger" id="ser_com2_msg"></span>
                    </div>
                    <div class="col-md-6 mb-4" id="com_div_3">
                        <label class="from-label mb-2">Commission 3</label>
                        <input type="text" readonly id="ser_com3" name="ser_com3" placeholder="Enter Commission 3" aria-describedby="emailHelp" class="form-control">
                        <span class="text-danger" id="ser_com3_msg"></span>
                    </div>
                    <div class="col-md-12">
                        <center><input type="submit" value="Submit" class="btn btn-info btn-sm"></center>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@section('custom_js')

<script>
    $('#aadhaar_card').change(function (e) {
                e.preventDefault();
                var x = $('#aadhaar_card').val();

                var url = "{{ route('admin.service_chk_single_data') }}";
                $.ajax({
                    type: "get",
                    url: url,
                    data: {
                        't_n': 'staffs',
                        'f_n': 'aadhaar_card',
                        'f_v': x
                    },
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        if(response.length==0){
                            $('other_section').show();
                        }
                        else{
                            $('other_section').hide();
                            $('#aadhaar_card_msg').html('<span class="text-danger" id="aadhaar_card_msg">Data Already Exist</span>');
                        }
                    }
                });

        });
</script>
@endsection
