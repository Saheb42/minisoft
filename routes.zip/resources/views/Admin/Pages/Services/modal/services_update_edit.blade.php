<div class="modal fade" id="editModal{{ $item->id }}" tabindex="-1" role="dialog" aria-labelledby="modal-block-fadein" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="block block-rounded block-transparent mb-0">
                <div class="block-header block-header-default">
                    <h3 class="block-title">Modify {{ $item->s_name }}</h3>
                    <div class="block-options">
                        <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
                            <i class="fa fa-fw fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="block-content fs-sm">
                    <form action="{{ route('admin.service_update') }}" method="post" class="row">
                        @csrf
                        <div class="mb-3 row">
                            <div class="col-md-12 mb-4">
                                <input type="hidden" name="update_id" value="{{ $item->id }}">
                                <label class="from-label mb-2 required">Service Name</label>
                                <input type="text" required value="{{ $item->s_name }}" id="update_ser_name" name="update_ser_name" placeholder="Enter Service Name" aria-describedby="emailHelp" class="form-control">
                                <div id="update_ser_name_msg">
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label class="from-label mb-2">Service Price</label>
                                <input type="text" value="{{ $item->s_price }}" id="update_ser_price" name="update_ser_price" placeholder="Enter Service Price" aria-describedby="emailHelp" class="form-control">
                                <span class="text-danger" id="update_ser_price_msg"></span>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label class="from-label mb-2">Expenses</label>
                                <input value="{{ $item->s_expenses }}" type="text" id="update_ser_expenses" name="update_ser_expenses" placeholder="Enter Expenses" aria-describedby="emailHelp" class="form-control">
                                <span class="text-danger" id="update_ser_expenses_msg"></span>
                            </div>
                            <div class="col-md-12 mb-4" id="com_div_1">
                                <label class="from-label mb-2">Commission 1</label>
                                <input value="{{ $item->s_com1 }}" type="text" id="update_ser_com1" name="update_ser_com1" placeholder="Enter Commission 1" aria-describedby="emailHelp" class="form-control">
                                <span class="text-danger" id="update_ser_com1_msg"></span>
                            </div>
                            <div class="col-md-6 mb-4" id="com_div_2">
                                <label class="from-label mb-2">Commission 2</label>
                                <input value="{{ $item->s_com2 }}" type="text" id="update_ser_com2" name="update_ser_com2" placeholder="Enter Commission 2" aria-describedby="emailHelp" class="form-control">
                                <span class="text-danger" id="update_ser_com2_msg"></span>
                            </div>
                            <div class="col-md-6 mb-4" id="com_div_3">
                                <label class="from-label mb-2">Commission 3</label>
                                <input value="{{ $item->s_com3 }}" type="text" id="update_ser_com3" name="update_ser_com3" placeholder="Enter Commission 3" aria-describedby="emailHelp" class="form-control">
                                <span class="text-danger" id="update_ser_com3_msg"></span>
                            </div>
                        </div>
                        <div class="text-center mb-3">
                            <button type="button" class="btn btn-sm btn-alt-secondary me-1"
                                data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-sm btn-primary" data-bs-dismiss="modal">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@section('custom_js')

<script>
    $('#update_ser_name').change(function (e) {
                e.preventDefault();
                var x = $('#update_ser_name').val();

                var y = '{{ $data[0]->s_name }}';
                var url = "{{ route('admin.service_chk_single_data') }}";
                $.ajax({
                    type: "get",
                    url: url,
                    data: {
                        't_n': 'services',
                        'f_n': 's_name',
                        'f_v': x
                    },
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        if(response.length==0){
                            $('#update_ser_name_msg').html('<span class="text-success" id="ser_name_msg">Data Not Exist</span>');
                        }
                        else{
                            if(response[0].s_name == y){
                                $('#update_ser_name').val(y);
                            $('#update_ser_name_msg').html('<span class="text-success" id="ser_name_msg"></span>');

                            }
                            else{
                            $('#update_ser_name').val('');
                            $('#update_ser_name_msg').html('<span class="text-danger" id="ser_name_msg">Data Already Exist</span>');
                            }
                        }
                    }
                });
        });
</script>


@endsection
