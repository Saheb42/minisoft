@extends('Admin.Layout.main')

@section('main_section')
<div class="card m-5">
    <div class="card-body text-center display-5 fw-bold">
        Welcome to Home Page
    </div>
</div>

@endsection
